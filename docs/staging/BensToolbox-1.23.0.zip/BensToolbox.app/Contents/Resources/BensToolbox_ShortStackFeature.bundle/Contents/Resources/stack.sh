#!/usr/bin/env bash
# STACK_SH_VERSION: 20
# ^ bumped whenever this script changes. Canonical source: vendor/stack.sh in the ShortStack repo
#   (this file); the app bundles it as a resource and installs it into the user's data dir.
#   The app replaces the installed copy when it is OLDER **or CANNOT SERVE the verbs the app
#   calls** — see stackScriptInstallAction / shortStackRequiredScriptCapabilities in StackCore.swift.
#   It never downgrades a CAPABLE script, and backs up the old file first. The version marker alone
#   was the pre-1.8.1 rule and it is exactly what broke: a file numbered high but missing `defer`
#   passed the gate and then failed at the point of use (app-feedback #10).
#
# v20 gives every push/push-many/restore creation an opaque `gen=<uuid>` in the existing ref field.
# v19 adds the `capabilities` verb (and a `selftest-capabilities` check for it), which is what lets
# the app ask instead of guessing. Scripts predating this verb hit the `*)` usage arm and exit
# non-zero, which the app reads as "reports nothing" -> replace; that is the right answer for them,
# so no version negotiation is needed.
# stack.sh — short-term LIFO "short stack" with an append-only TSV transaction log.
# Hardened (per gpt-5.5 review): mkdir-lock concurrency, strict errors, control-char
# sanitization, numeric input validation, .stack_seq recovery. Portable macOS/BSD + Linux.
#
# State files (same dir as this script):
#   STACK.md    live stack; one item per line as TSV: <id>\t<push_epoch>\t<text>  (newest at bottom)
#   STACK.log   append-only audit log (TSV, never trimmed): iso_ts\tepoch\top\tid\tactor\tref\titem
#   .stack_seq  monotonic id counter ;  .stack.lock  mkdir mutex
#
# Nothing edits STACK.md by hand — the agent/app/CLI only call these subcommands.
# Actor from $STACK_ACTOR (agent|app|cli), default cli.
#
# Subcommands: push [--dest D][--win W][--ttl S][--exp S][--wake S][--cat C --max N] <t> |
#              push-many <a> <b>.. |
#              pop | pop-clip | peek | peek-clip | show | count | clear | remove <id> |
#              move <id> <pos> | edit <id> <t> | defer <id> <seconds> | restore <id> |
#              history [N] | as-of <epoch>
#   push --exp S : item auto-removes S seconds from now (expiry).  --wake S : item hidden until S
#   seconds from now (schedule a future item).  defer <id> S : hide an existing item S seconds (snooze).
set -euo pipefail
umask 077  # the log holds private todo text: create STACK.md/STACK.log/.stack_seq 0600, not 0644

DIR="$(cd "$(dirname "$0")" && pwd)"
F="$DIR/STACK.md"
LOG="$DIR/STACK.log"
SEQ="$DIR/.stack_seq"
LOCK="$DIR/.stack.lock"

# collapse ALL control chars (tab, newline, CR, ESC, ...) to spaces -> one safe TSV cell
# LC_ALL=C: locale-aware tr dies with "Illegal byte sequence" on non-UTF-8 bytes under a UTF-8
# locale (and set -e then kills EVERY subcommand); bytewise operation can't fail and leaves
# valid UTF-8 multibyte content untouched.
sanitize(){ printf '%s' "${1-}" | LC_ALL=C tr '[:cntrl:]' ' '; }
is_int(){ case "${1-}" in ''|*[!0-9]*) return 1;; *) return 0;; esac }

ACTOR="$(sanitize "${STACK_ACTOR:-cli}")"

# ---- portable mutex: mkdir is atomic; reclaim ONLY a dead holder's lock ----
# The lock dir carries the holder PID. After ~1s of waiting we inspect it: if the
# holder process is still ALIVE (merely slow), we keep waiting and never steal —
# stealing a live holder would let two writers race and clobber STACK.md. If the
# holder is dead/unknown (crashed mid-op), we reclaim the stale lock. ~30s hard cap.
# The dead-holder check MUST fire well inside the ShortStack app's 5s subprocess
# timeout: at the old 5s threshold, reclaim always lost the race to the kill, so one
# stale lock (holder SIGKILLed, EXIT trap never ran) made EVERY app mutation time
# out forever — pushes appeared then vanished with "timed out after 5.0s".
acquire_lock(){
  local tries=0 waited=0 pidless=0 holder
  while ! mkdir "$LOCK" 2>/dev/null; do
    sleep 0.05; waited=$((waited + 1)); tries=$((tries + 1))
    if [ -f "$LOCK/pid" ]; then pidless=0; else pidless=$((pidless + 1)); fi
    if [ "$tries" -ge 20 ]; then
      tries=0
      holder="$(cat "$LOCK/pid" 2>/dev/null || true)"
      if [ -n "$holder" ] && kill -0 "$holder" 2>/dev/null; then
        :                                   # holder ALIVE (slow) -> wait, never steal
      elif [ -n "$holder" ]; then
        # kill -0 also fails with EPERM (alive, owned by another user — a shared dir). Steal
        # ONLY from a definitively-dead holder; ps is the portable existence check.
        if ps -p "$holder" >/dev/null 2>&1; then
          :                                 # alive but not signalable -> wait, never steal
        else
          rm -rf "$LOCK" 2>/dev/null || true  # dead holder -> reclaim stale lock
        fi
      elif [ "$pidless" -ge 60 ]; then
        # No pid file: a LIVE holder writes its pid microseconds after mkdir, so a lock that
        # stays pid-less for a continuous ~3s means the holder died in that window. Reclaim —
        # 1s (first check) + 3s lands inside the app's 5s subprocess timeout; a -mmin +1 age
        # threshold (previous policy) blocked every mutation for up to 60s.
        rm -rf "$LOCK" 2>/dev/null || true
      fi
    fi
    if [ "$waited" -ge 600 ]; then
      echo "stack: lock busy >30s, giving up" >&2; exit 1
    fi
  done
  printf '%s\n' "$$" > "$LOCK/pid" 2>/dev/null || true
  # Cleanup on EXIT only; a trapped INT/TERM handler that doesn't exit would RESUME the script
  # after dropping the lock — two writers racing, which is exactly what the lock prevents.
  trap 'rm -rf "$LOCK" 2>/dev/null || true' EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
}
# Every verb this script dispatches, one per line. This is a DECLARATION, not a guess: the app
# reads it to decide whether the on-disk script can serve it.
#
# The two drift directions are NOT symmetric, deliberately:
#   - listed here but NOT dispatched below = a LIE, and the dangerous direction: it would let an
#     incapable script pass the app's gate and fail at the point of use — the exact shape of
#     app-feedback #10. `stack.sh selftest-capabilities` invokes every token and fails on any that
#     falls through to the usage arm, so this direction cannot drift silently.
#   - dispatched below but NOT listed here = merely conservative: the app reads the verb as
#     unsupported and upgrades a script that would in fact have served. Costs one needless file
#     write, never a broken feature. Detecting it would mean parsing the case block, i.e. the app
#     re-deriving the script's own rules instead of asking it — the mirror trap. Left uncaught on
#     purpose.
STACK_SH_CAPABILITIES='push
push-many
pop
pop-clip
peek
peek-clip
show
count
clear
remove
move
edit
defer
restore
history
as-of
dump-tsv
as-of-index
capabilities'

# ---------------------------------------------------------------------------------------------
# LOCK-FREE VERBS. Dispatched BEFORE acquire_lock because they read nothing from the stack and
# write nothing to it — they only report what this file can do.
#
# `capabilities` used to fall through to the main dispatch below, which meant it waited on the
# stack mutex like any mutation. That made the app's launch-time probe a hostage to whatever else
# was touching the data dir. Measured on bender, 2026-07-24:
#
#     uncontended            0.03s
#     concurrent push        0.12-0.17s
#     stale lock, dead pid   3.43s
#     stale lock, no pidfile 10.61s
#     lock held by a live holder  67.21s   (then "lock busy >30s, giving up")
#
# The app probes with a 0.5s timeout, so contention — not breakage — made the probe time out. A
# timed-out probe reported NOTHING, which the old decision logic read as "this script cannot
# serve the app" and upgraded: a newer, possibly locally-modified stack.sh in a SHARED data dir
# got backed up and overwritten, silently, because the write then succeeded and produced no gap
# and therefore no notice. Ben's work Mac — where another assistant shares ~/copilot-pa and can be
# holding this very lock — is exactly where that would bite.
#
# A capability declaration is a property of the FILE, not of the stack state, so serialising it
# behind the state mutex was never meaningful. Answering before the lock removes the contention
# class outright rather than raising a timeout until it is rare.
case "${1:-}" in
  capabilities)
    printf '%s\n' "$STACK_SH_CAPABILITIES"
    exit 0
    ;;

  # Lock-free for the same reason as `capabilities`, plus a sharper one found in review: when this
  # arm was dispatched from the main (post-lock) case, its own `trap ... EXIT` REPLACED
  # acquire_lock's cleanup trap, so the caller's `.stack.lock` was left behind holding a now-dead
  # pid. Measured: the next command then paid the stale-lock reclaim path at 3.98s and 4.13s —
  # against the app's 5s ShellRunner default, on a data dir that may be shared with another
  # assistant. It isolated the state FILES but not the LOCK.
  #
  # It needs nothing from the caller's stack (every verb runs against a COPY in a temp dir), so
  # answering before the lock is both correct and removes the trap collision outright, rather than
  # chaining traps and depending on the ordering staying right.
  selftest-capabilities)
    # Prove the declaration above matches the dispatch below: run every declared verb and fail on
    # any that falls through to the usage arm. Guards against the declaration and the case block
    # drifting apart (same file, but not the same edit). Intentionally NOT itself a capability —
    # a developer/CI check, not app API.
    #
    # Every verb runs against a COPY of this script in a throwaway dir, because the state files
    # live beside the script ($DIR, line ~38) and several declared verbs mutate: a naive `"$0" pop`
    # here would pop the caller's real stack, and `clear` would empty it. Isolation is the whole
    # reason this arm copies rather than invoking in place.
    st_tmp="$(mktemp -d "${TMPDIR:-/tmp}/stack-selftest.XXXXXX")" || {
      echo "selftest: cannot create temp dir" >&2; exit 1; }
    trap 'rm -rf "$st_tmp"' EXIT INT TERM HUP
    cp "$0" "$st_tmp/stack.sh" || { echo "selftest: cannot copy script" >&2; exit 1; }
    chmod 0700 "$st_tmp/stack.sh"
    rc=0
    for v in $STACK_SH_CAPABILITIES; do
      out="$(bash "$st_tmp/stack.sh" "$v" 2>&1 </dev/null || true)"
      case "$out" in
        "usage: stack.sh"*) echo "selftest: declared verb '$v' is NOT dispatched" >&2; rc=1 ;;
      esac
    done
    [ "$rc" -eq 0 ] && echo "selftest-capabilities: all $(printf '%s\n' "$STACK_SH_CAPABILITIES" | grep -c .) declared verbs dispatch"
    exit "$rc"
    ;;
esac

acquire_lock

# init state under the lock
[ -f "$F" ]   || : > "$F"
[ -f "$LOG" ] || printf 'iso_ts\tepoch\top\tid\tactor\tref\titem\n' > "$LOG"
# umask only covers NEW files: pre-existing state files (created before umask 077, e.g. 0644)
# keep their old modes across upgrades — tighten them here, under the lock.
for f in "$F" "$LOG" "$SEQ"; do
  [ -e "$f" ] && chmod go-rwx "$f" 2>/dev/null || true
done
if [ ! -f "$SEQ" ]; then
  # recover the counter from the highest id ever seen (log col 4 + live col 1)
  maxid="$( { awk -F'\t' 'NR>1{print $4}' "$LOG" 2>/dev/null || true; cut -f1 "$F" 2>/dev/null || true; } \
            | awk 'BEGIN{m=0} /^[0-9]+$/{if($1+0>m)m=$1} END{print m}')"
  printf '%s\n' "${maxid:-0}" > "$SEQ"
fi

next_id(){ local n; n="$(cat "$SEQ")"; n=$((n + 1)); printf '%s\n' "$n" > "$SEQ"; printf '%s' "$n"; }

new_generation(){
  if command -v uuidgen >/dev/null 2>&1; then
    uuidgen
  elif command -v openssl >/dev/null 2>&1; then
    openssl rand -hex 16
  elif [ -r /dev/urandom ] && command -v od >/dev/null 2>&1; then
    od -An -N16 -tx1 /dev/urandom | tr -d ' \n'
  else
    echo "stack.sh: no secure UUID/random generator available" >&2
    return 1
  fi
}

with_generation(){ # existing ref -> fresh gen=<opaque uuid>;existing metadata (old gen removed)
  local ref gen rest
  ref="${1:--}"
  gen="$(new_generation)"
  rest="$(printf '%s' "$ref" | tr ';' '\n' | awk '$0!="-" && !/^gen=/' | paste -sd ';' -)"
  if [ -n "$rest" ]; then printf 'gen=%s;%s' "$gen" "$rest"; else printf 'gen=%s' "$gen"; fi
}

log_event(){ # op id ref item  (actor is the global $ACTOR)
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$(date '+%s')" \
    "$(sanitize "$1")" "$(sanitize "$2")" "$ACTOR" "$(sanitize "$3")" "$(sanitize "$4")" >> "$LOG"
}

to_clip(){ # stdin -> clipboard, best-effort, silent on failure
  if   command -v pbcopy  >/dev/null 2>&1; then pbcopy 2>/dev/null
  elif command -v wl-copy >/dev/null 2>&1; then wl-copy 2>/dev/null
  elif command -v xclip   >/dev/null 2>&1; then xclip -selection clipboard 2>/dev/null
  else cat >/dev/null; return 1; fi
}

build_ref(){ # dest win ttl exp wake cat -> "k=v;k=v" or "-"  (delimiters stripped from values)
  local d w t xp wk ct parts san
  d="$1"; w="$2"; t="$3"; xp="${4:-}"; wk="${5:-}"; ct="${6:-}"; parts=""
  san(){ printf '%s' "${1-}" | LC_ALL=C tr ';=\t\n' '    '; }
  [ -n "$d" ] && parts="dest=$(san "$d")"
  [ -n "$w" ] && parts="${parts:+$parts;}win=$(san "$w")"
  if [ -n "$t" ];  then is_int "$t"  && parts="${parts:+$parts;}ttl=$t";   fi
  if [ -n "$xp" ]; then is_int "$xp" && parts="${parts:+$parts;}exp=$xp";  fi   # absolute epoch
  if [ -n "$wk" ]; then is_int "$wk" && parts="${parts:+$parts;}wake=$wk"; fi   # absolute epoch
  [ -n "$ct" ] && parts="${parts:+$parts;}cat=$(san "$ct")"                     # freeform category (C)
  printf '%s' "${parts:--}"
}

# Live ids (present in STACK.md) that share the CATEGORY OF item $1, emitted in STACK.md order —
# line 1 of STACK.md = bottom of the stack = FARTHEST-DOWN, so the first line out is the eviction
# victim (Ben, 2026-07-22). Membership is decided ENTIRELY inside awk: it reads the target's category
# AND every candidate's category from the same stored log (col 6 `cat=`), comparing awk-string to
# awk-string. The category value NEVER crosses the shell→awk boundary (no `-v`, no `tr`), so it is
# immune to the value — backslash, `;`, `=`, unicode. That is the round-3 design fix: the round-1
# (delimiter) and round-2 (backslash) blockers were both "stored != queried" because the category was
# round-tripped through shell quoting; comparing stored-vs-stored inside one awk cannot have that bug.
# Hidden (deferred/expired) items count and are evictable — Ben's call; stack.sh treats STACK.md as
# the whole live set (an evicted item still lands in History, recoverable via `restore`).
cat_live_ids_of(){ # $1 = target id (just pushed); echoes matching live ids, farthest-down first
  TARGET="$1" awk -F'\t' '
    NR==FNR {                                                       # pass 1 = LOG: id -> category
      if($3=="push"||$3=="push-many"||$3=="restore"){
        c=""; n=split($6,p,";"); for(i=1;i<=n;i++) if(p[i] ~ /^cat=/) c=substr(p[i],5); catof[$4]=c
      }
      next
    }
    FNR==1 { want=catof[ENVIRON["TARGET"]] }                        # target category, from the LOG
    (want!="" && catof[$1]==want){ print $1 }                       # pass 2 = STACK.md, in line order
  ' "$LOG" "$F"
}

push_item(){ # text [op=push] [ref=-] -> echoes new id
  local text op ref id
  text="$(sanitize "$1")"; op="${2:-push}"; ref="$(with_generation "${3:--}")"
  id="$(next_id)"
  printf '%s\t%s\t%s\n' "$id" "$(date '+%s')" "$text" >> "$F"
  log_event "$op" "$id" "$ref" "$text"
  printf '%s' "$id"
}


sub="${1:-show}"; if [ "$#" -gt 0 ]; then shift; fi
case "$sub" in
  # NOTE: `capabilities` is NOT dispatched here — it is answered before acquire_lock (see the
  # LOCK-FREE VERBS block above), so it cannot be delayed by stack contention. An arm here too
  # would be unreachable, and an unreachable duplicate of a security-relevant answer is worse
  # than no duplicate: it reads as the live implementation while never running.
  push)
    dest=""; win=""; ttl=""; exp=""; wake=""; cat=""; max=""; now="$(date '+%s')"
    while [ "$#" -gt 0 ]; do
      case "$1" in
        --dest) [ $# -ge 2 ] || { echo "push: --dest needs a value" >&2; exit 1; }; dest="$2"; shift 2 ;;
        --win)  [ $# -ge 2 ] || { echo "push: --win needs a value" >&2; exit 1; };  win="$2";  shift 2 ;;
        --ttl)  [ $# -ge 2 ] || { echo "push: --ttl needs a value" >&2; exit 1; };  ttl="$2";  shift 2 ;;   # seconds; urgency starts after this elapses
        # --exp/--wake take SECONDS FROM NOW and are stored as absolute epochs, so a delayed
        # write (queued, retried) still expires/wakes at the intended wall-clock time.
        --exp)  [ $# -ge 2 ] || { echo "push: --exp needs seconds" >&2; exit 1; }; is_int "$2" || { echo "push: --exp must be an integer (seconds)" >&2; exit 1; }; exp=$((now + $2)); shift 2 ;;   # auto-remove after N seconds
        --wake) [ $# -ge 2 ] || { echo "push: --wake needs seconds" >&2; exit 1; }; is_int "$2" || { echo "push: --wake must be an integer (seconds)" >&2; exit 1; }; wake=$((now + $2)); shift 2 ;;  # hidden until N seconds from now (schedule/defer)
        # --cat: freeform category. --max N: if pushing makes the category exceed N live items, the
        # FARTHEST-DOWN item in that category is evicted (logged op=evict, kept in History). BOTH the
        # space form (`--cat X`) and the equals form (`--cat=X`) are accepted: an agent writing the
        # documented `--cat=work --max=3` must NOT have it silently swallowed into the item text with
        # no quota (Fable r2). is_int rejects a mangled `--max=` just like the space form.
        --cat)   [ $# -ge 2 ] || { echo "push: --cat needs a value" >&2; exit 1; }; cat="$2"; shift 2 ;;
        --cat=*) cat="${1#--cat=}"; shift ;;
        --max)   [ $# -ge 2 ] || { echo "push: --max needs a value" >&2; exit 1; }; { is_int "$2" && [ "$2" -ge 1 ]; } || { echo "push: --max must be a positive integer (>= 1)" >&2; exit 1; }; max="$2"; shift 2 ;;
        --max=*) mv_="${1#--max=}"; { is_int "$mv_" && [ "$mv_" -ge 1 ]; } || { echo "push: --max must be a positive integer (>= 1)" >&2; exit 1; }; max="$mv_"; shift ;;
        --) shift; break ;;
        *) break ;;
      esac
    done
    text="$*"
    [ -n "${text//[[:space:]]/}" ] || { echo "push: nothing to push" >&2; exit 1; }
    # The category is stored VERBATIM and compared byte-for-byte inside awk (cat_live_ids_of), so a
    # category is either accepted UNCHANGED or REJECTED — there is NO value transformation between input
    # and storage. That is the terminal fix for the category-value class: rounds 1-3 each found a defect
    # rooted in transforming the category (r1 `;`/`=` silently disabled the quota; r2 backslash via
    # `awk -v`; r3 the `tr ';=' '  '` munge collapsed DISTINCT freeform inputs like `x=y` and `x y` into
    # one bucket — codex, a mis-enforcement against the "freeform = identity-by-string" spec). With zero
    # transformation, stored==input==queried for every accepted value AND distinct inputs stay distinct.
    # So reject the only bytes that cannot live verbatim in a single TSV row's `k=v;` bag: `;`, `=`, and
    # control chars. Everything else (backslash, spaces, unicode, `c:\temp`, `x-y`) is kept exactly.
    # Byte-count check, NOT `grep` — grep is line-oriented, so an EMBEDDED NEWLINE (itself a control
    # char that would split the TSV row into two) is a record separator grep never sees. tr -d the
    # disallowed bytes and compare byte length: any difference means a `;`, `=`, or control char
    # (newline/tab/ESC/...) was present. LC_ALL=C keeps tr bytewise (no locale "illegal byte" death).
    if [ -n "$cat" ]; then
      _corig="$(printf '%s' "$cat" | wc -c)"
      _cclean="$(printf '%s' "$cat" | LC_ALL=C tr -d ';=[:cntrl:]' | wc -c)"
      [ "$_corig" -eq "$_cclean" ] || { echo "push: --cat may not contain ';', '=', or control characters" >&2; exit 1; }
    fi
    # A quota needs a real category. Reject --max when the category is empty / only whitespace, BEFORE
    # the push, so there is no partial write and no silent unenforced cap (`--cat '' --max 1` used to
    # push rc=0 with no quota). An interior space (e.g. "code review") trims non-empty and is fine.
    if [ -n "$max" ] && [ -z "$(printf '%s' "$cat" | tr -d '[:space:]')" ]; then
      echo "push: --max requires a non-empty --cat" >&2; exit 1
    fi
    id="$(push_item "$text" "push" "$(build_ref "$dest" "$win" "$ttl" "$exp" "$wake" "$cat")")"
    echo "pushed #$id: $(sanitize "$text")"
    # Category quota (C): enforce AFTER the push, so the new item counts. Evict the FARTHEST-DOWN item
    # (bottom of the stack, = first STACK.md line) in the category while over max — NOT the smallest id
    # (Ben, 2026-07-22: a `move` that promotes an old item must not make it the eviction victim). Loop
    # in case max was lowered. cat_live_ids_of already emits farthest-down first, so take the first.
    if [ -n "$cat" ] && [ -n "$max" ]; then
      while :; do
        ids="$(cat_live_ids_of "$id")"
        n="$(printf '%s\n' "$ids" | awk 'NF{c++} END{print c+0}')"   # awk, not `grep -c` (rc=1 on 0 kills pipefail)
        [ "$n" -gt "$max" ] || break
        ev="$(printf '%s\n' "$ids" | awk 'NF{print; exit}')"          # farthest-down live id in the category
        [ -n "$ev" ] || break
        evtext="$(awk -F'\t' -v id="$ev" '$1==id{print $3; exit}' "$F")"
        # Crash-safety: LOG the evict BEFORE mutating STACK.md (codex r2). If we die between the two, the
        # log is authoritative — replay/recompute drops the item and History has the record — instead of
        # STACK.md silently losing the row with no evict event. The whole push+evict runs under the mkdir
        # lock, so no reader observes the window. If the STACK.md rewrite/mv then FAILS (e.g. ENOSPC), do
        # NOT `break` to a false success (codex r3): the evict is already committed to the log, so exit
        # nonzero to surface it — the log stays authoritative and a later replay reconciles STACK.md.
        log_event "evict" "$ev" "cat=$cat" "$evtext"                  # cat has no ;/=/cntrl (rejected at parse)
        tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
        if awk -F'\t' -v id="$ev" '$1!=id{print}' "$F" > "$tmp" && mv "$tmp" "$F"; then :; else
          rm -f "$tmp"; echo "push: #$ev evicted in log but STACK.md rewrite failed; log is authoritative" >&2; exit 1
        fi
        echo "evicted #$ev (category $cat over max $max)"            # cat has no control chars (rejected at parse)
      done
    fi
    ;;

  push-many)
    n=0
    for item in "$@"; do
      [ -n "${item//[[:space:]]/}" ] || continue
      push_item "$item" "push-many" >/dev/null
      n=$((n + 1))
    done
    echo "pushed $n item(s)"
    ;;

  pop|pop-clip)
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    last="$(tail -n 1 "$F")"
    id="$(printf '%s' "$last" | cut -f1)"
    text="$(printf '%s' "$last" | cut -f3-)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! sed '$d' "$F" > "$tmp"; then rm -f "$tmp"; echo "pop: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    if [ "$sub" = pop-clip ]; then
      if printf '%s' "$text" | to_clip; then note=" (copied to clipboard)"; else note=" (clipboard unavailable)"; fi
      log_event "pop-clip" "$id" "-" "$text"
      echo "popped #$id$note: $text"
    else
      log_event "pop" "$id" "-" "$text"
      echo "popped #$id: $text"
    fi
    ;;

  peek|peek-clip)
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    last="$(tail -n 1 "$F")"
    id="$(printf '%s' "$last" | cut -f1)"
    text="$(printf '%s' "$last" | cut -f3-)"
    if [ "$sub" = peek-clip ]; then
      if printf '%s' "$text" | to_clip; then note=" (copied to clipboard)"; else note=" (clipboard unavailable)"; fi
      log_event "peek-clip" "$id" "-" "$text"
      echo "top #$id$note: $text"
    else
      echo "top #$id: $text"
    fi
    ;;

  show)
    if [ ! -s "$F" ]; then echo "stack is empty (0 items)"; exit 0; fi
    awk -F'\t' -v now="$(date '+%s')" '
      {a[NR]=$0}
      END{
        k=0
        for(i=NR;i>=1;i--){
          split(a[i],c,"\t"); id=c[1]; ep=c[2]; txt=c[3]; d=now-ep
          if(d<60)         age=d "s"
          else if(d<3600)  age=int(d/60) "m"
          else if(d<86400) age=int(d/3600) "h"
          else             age=int(d/86400) "d"
          printf "%d. %s  (#%s, %s ago)\n", ++k, txt, id, age
        }
      }' "$F"
    ;;

  count)
    awk 'END{print NR+0}' "$F"
    ;;

  clear)
    if [ "$#" -gt 0 ]; then
      # SELECTIVE clear: remove ONLY the given ids from STACK.md and record them in ONE `clear` event
      # (item field = space-separated ids). The app uses this to clear the VISIBLE stack while hidden
      # deferred items survive, and so History shows a single "cleared" action, not N "removed".
      for x in "$@"; do is_int "$x" || { echo "clear: ids must be positive integers" >&2; exit 1; }; done
      ids="$*"
      tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
      # keep every md line whose id (col 1) is NOT in the id set
      if ! IDS=" $ids " awk -F'\t' 'BEGIN{OFS="\t"; n=split(ENVIRON["IDS"],a," "); for(i=1;i<=n;i++) drop[a[i]]=1}
                                    !($1 in drop){print}' "$F" > "$tmp"; then
        rm -f "$tmp"; echo "clear: write failed" >&2; exit 1
      fi
      mv "$tmp" "$F"
      log_event "clear" "-" "-" "$ids"
      echo "cleared: $ids"
    else
      log_event "clear" "-" "-" ""     # legacy whole-stack clear (CLI)
      : > "$F"
      echo "stack cleared"
    fi
    ;;

  remove)
    target="${1:-}"
    is_int "$target" || { echo "remove: id must be a positive integer" >&2; exit 1; }
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "remove: id #$target not in stack" >&2; exit 1; }
    text="$(printf '%s' "$line" | cut -f3-)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! awk -F'\t' -v id="$target" '$1!=id' "$F" > "$tmp"; then rm -f "$tmp"; echo "remove: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    log_event "remove" "$target" "-" "$text"
    echo "removed #$target: $text"
    ;;

  move)
    # move <id> <pos> — reorder a live item to position <pos>, 1-based from the TOP
    # (matching `show` numbering: 1 = top). Appends op=move with ref "to=<pos>".
    target="${1:-}"; pos="${2:-}"
    is_int "$target" || { echo "move: id must be a positive integer" >&2; exit 1; }
    is_int "$pos" || { echo "move: position must be a positive integer (1 = top)" >&2; exit 1; }
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "move: id #$target not in stack" >&2; exit 1; }
    text="$(printf '%s' "$line" | cut -f3-)"
    n="$(awk 'END{print NR+0}' "$F")"
    [ "$pos" -ge 1 ] || pos=1
    [ "$pos" -le "$n" ] || pos="$n"
    # STACK.md is newest-at-bottom, so position <pos> from the top = line (n - pos + 1).
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! awk -F'\t' -v id="$target" -v pos="$pos" -v n="$n" '
      BEGIN{ dest=n-pos+1 }
      $1==id{ saved=$0; next }
      { rest[++k]=$0 }
      END{
        printed=0
        for(i=1;i<=k+1;i++){
          if(i==dest){ print saved; printed=1 }
          if(i<=k) print rest[i]
        }
        if(!printed) print saved
      }' "$F" > "$tmp"; then rm -f "$tmp"; echo "move: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    log_event "move" "$target" "to=$pos" "$text"
    echo "moved #$target to position $pos: $text"
    ;;

  edit)
    # edit <id> <text…> — replace a live item's text in place (id + push epoch preserved,
    # so age/urgency are unaffected). Appends op=edit with the new text.
    target="${1:-}"; shift || true
    is_int "$target" || { echo "edit: id must be a positive integer" >&2; exit 1; }
    text="$(sanitize "$*")"
    [ -n "${text//[[:space:]]/}" ] || { echo "edit: nothing to set" >&2; exit 1; }
    # A dropped edit is USER DATA LOSS (their typed text) — unlike pop/move, an empty stack
    # here must fail loudly (exit 1 + stderr) so the app surfaces it instead of silently
    # reverting the optimistic text.
    [ -s "$F" ] || { echo "edit: stack is empty; #$target is gone" >&2; exit 1; }
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "edit: id #$target not in stack" >&2; exit 1; }
    ep="$(printf '%s' "$line" | cut -f2)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    # text via ENVIRON (awk -v mangles backslashes)
    if ! TXT="$text" awk -F'\t' -v id="$target" -v ep="$ep" \
        'BEGIN{OFS="\t"; t=ENVIRON["TXT"]} $1==id{print id,ep,t; next} {print}' "$F" > "$tmp"; then
      rm -f "$tmp"; echo "edit: write failed" >&2; exit 1
    fi
    mv "$tmp" "$F"
    log_event "edit" "$target" "-" "$text"
    echo "edited #$target: $text"
    ;;

  defer)
    # defer <id> <seconds> — hide a live item until <seconds> from now (snooze). Stores
    # wake=<absolute epoch> in the log ref; the app hides the item until then and reveals it after.
    # The item stays in STACK.md (wake lives only in the log), so a client that ignores wake still
    # sees it — nothing is lost. Seconds → absolute epoch so a delayed write still wakes on time.
    target="${1:-}"; secs="${2:-}"
    is_int "$target" || { echo "defer: id must be a positive integer" >&2; exit 1; }
    is_int "$secs"   || { echo "defer: seconds must be a non-negative integer" >&2; exit 1; }
    [ -s "$F" ] || { echo "defer: stack is empty; #$target is gone" >&2; exit 1; }
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "defer: id #$target not in stack" >&2; exit 1; }
    text="$(printf '%s' "$line" | cut -f3-)"   # current text (may contain tabs) for a self-describing log line
    wake=$(( $(date '+%s') + secs ))
    log_event "defer" "$target" "wake=$wake" "$text"
    echo "deferred #$target until $wake"
    ;;

  restore)
    target="${1:-}"
    is_int "$target" || { echo "restore: id must be a positive integer" >&2; exit 1; }
    item="$(awk -F'\t' -v id="$target" \
      '($3=="push"||$3=="push-many"||$3=="restore") && $4==id {v=$7} END{print v}' "$LOG")"
    [ -n "$item" ] || { echo "restore: id #$target not found in log" >&2; exit 1; }
    origref="$(awk -F'\t' -v id="$target" \
      '($3=="push"||$3=="push-many"||$3=="restore") && $4==id {v=$6} END{print v}' "$LOG")"
    [ -n "$origref" ] || origref="-"
    # Drop exp=/wake= from the inherited ref: restore is an explicit "I want this back NOW", but the
    # original ref may carry a PAST exp (→ the restored item lands already-expired and invisible) or a
    # wake (→ re-deferred). dest/win/ttl are fine to keep. (Fable: restore of an expired item.)
    # Use awk, NOT `grep -vE`: when the ref is ONLY exp=/wake=, grep matches nothing and returns rc=1,
    # which under `set -o pipefail` + `set -e` killed the whole restore silently (rc=1, nothing back).
    # awk exits 0 even when it prints no lines, so an exp/wake-only ref restores cleanly (ref → "-").
    origref="$(printf '%s' "$origref" | tr ';' '\n' | awk '!/^(exp|wake)=/' | paste -sd ';' -)"
    [ -n "$origref" ] || origref="-"
    if [ "$origref" = "-" ]; then ref="src=$target"; else ref="$origref;src=$target"; fi
    newid="$(push_item "$item" "restore" "$ref")"
    echo "restored #$target as #$newid: $item"
    ;;

  history)
    n="${1:-20}"
    is_int "$n" || { echo "history: N must be a positive integer" >&2; exit 1; }
    echo "(last $n transactions)"
    tail -n "$n" "$LOG" | awk -F'\t' '$1!="iso_ts"{printf "%s  %-9s #%-4s %-6s %s\n",$1,$3,$4,$5,$7}'
    ;;

  # ---- Log-replayers (as-of / dump-tsv / as-of-index) ----
  # CONTRACT: these reconstruct the stack from the append-only log and are guaranteed to agree with
  # STACK.md and with the app's Swift StackParser.replay ON WELL-FORMED LOGS — i.e. any log produced by
  # a real writer (this script's own subcommands + the app). Every op these emit (`move` included) is
  # written in a fixed, validated shape: `move` always logs `to=<clamped-positive-int>` and nothing else.
  # Parity on a HAND-CORRUPTED log (a move ref with whitespace-padded keys, non-integer/overflow values,
  # or extra bag keys) is NOT a goal and is UNSPECIFIED: byte-oriented awk cannot exactly mirror Swift's
  # Unicode-aware key trimming and Int64 bounds, and no writer can produce such a ref. See ticket
  # "replayer/StackParser tamper-log move-ref parity" (1.6.1, deferred by design — Ben 2026-07-22).
  as-of)
    when="${1:-}"
    is_int "$when" || { echo "as-of: needs an epoch timestamp (integer)" >&2; exit 1; }
    awk -F'\t' -v cut="$when" '
      function drop(x,   i,j){ for(i=1;i<=top;i++) if(sid[i]==x){ for(j=i;j<top;j++){sid[j]=sid[j+1];stx[j]=stx[j+1]} top--; return } }
      $1=="iso_ts"{next}
      $2+0>cut{next}
      { op=$3; id=$4; txt=$7 }
      op=="push"||op=="push-many"||op=="restore"{ top++; sid[top]=id; stx[top]=txt; next }
      op=="pop"||op=="pop-clip"{ if(top>0) top--; next }
      op=="remove"||op=="evict"{ drop(id); next }
      op=="clear"{ if($7==""||$7=="-"){top=0} else {nc=split($7,cl," "); for(ci=1;ci<=nc;ci++) drop(cl[ci])} next }
      function moveid(id, pos,   j,i,n,Ai,At,d){ n=top; for(j=1;j<=top;j++) if(sid[j]==id) break; if(j>top) return; Ai=sid[j]; At=stx[j]; for(i=j;i<top;i++){sid[i]=sid[i+1];stx[i]=stx[i+1]} top--; if(pos<1)pos=1; if(pos>n)pos=n; d=n-pos+1; for(i=top;i>=d;i--){sid[i+1]=sid[i];stx[i+1]=stx[i]} sid[d]=Ai; stx[d]=At; top++ }
      op=="edit"{ for(i=1;i<=top;i++) if(sid[i]==id) stx[i]=txt; next }
      op=="move"{ mp=""; nq=split($6,qq,";"); for(qi=1;qi<=nq;qi++) if(qq[qi]~/^to=/){mp=substr(qq[qi],4);break} if(mp~/^[+-]?[0-9]+$/) moveid(id,mp+0); next }   # to=<int> only; a malformed/absent ref is a NO-OP, matching Swift parseMoveTarget (refValue("to").flatMap(Int.init))
      END{
        if(top<1){ print "stack was empty at that time"; exit }
        k=0
        for(i=top;i>=1;i--) printf "%d. %s  (#%s)\n", ++k, stx[i], sid[i]
      }' "$LOG"
    ;;

  dump-tsv)
    # Machine-readable current stack, top last: id<TAB>epoch<TAB>actor<TAB>text  (PRD §12 R2)
    [ -f "$LOG" ] || exit 0
    awk -F'\t' '
      function drop(x,   i,j){ for(i=1;i<=top;i++) if(sid[i]==x){ for(j=i;j<top;j++){sid[j]=sid[j+1];sep[j]=sep[j+1];sac[j]=sac[j+1];stx[j]=stx[j+1]} top--; return } }
      $1=="iso_ts"{next}
      { op=$3; id=$4; ep=$2; ac=$5; tx=$7 }
      op=="push"||op=="push-many"||op=="restore"{ top++; sid[top]=id; sep[top]=ep; sac[top]=ac; stx[top]=tx; next }
      op=="pop"||op=="pop-clip"{ if(top>0) top--; next }
      op=="remove"||op=="evict"{ drop(id); next }
      op=="clear"{ if($7==""||$7=="-"){top=0} else {nc=split($7,cl," "); for(ci=1;ci<=nc;ci++) drop(cl[ci])} next }
      function moveid(id, pos,   j,i,n,Ai,Ae,Aa,At,d){ n=top; for(j=1;j<=top;j++) if(sid[j]==id) break; if(j>top) return; Ai=sid[j]; Ae=sep[j]; Aa=sac[j]; At=stx[j]; for(i=j;i<top;i++){sid[i]=sid[i+1];sep[i]=sep[i+1];sac[i]=sac[i+1];stx[i]=stx[i+1]} top--; if(pos<1)pos=1; if(pos>n)pos=n; d=n-pos+1; for(i=top;i>=d;i--){sid[i+1]=sid[i];sep[i+1]=sep[i];sac[i+1]=sac[i];stx[i+1]=stx[i]} sid[d]=Ai; sep[d]=Ae; sac[d]=Aa; stx[d]=At; top++ }
      op=="edit"{ for(i=1;i<=top;i++) if(sid[i]==id) stx[i]=tx; next }
      op=="move"{ mp=""; nq=split($6,qq,";"); for(qi=1;qi<=nq;qi++) if(qq[qi]~/^to=/){mp=substr(qq[qi],4);break} if(mp~/^[+-]?[0-9]+$/) moveid(id,mp+0); next }   # to=<int> only; a malformed/absent ref is a NO-OP, matching Swift parseMoveTarget (refValue("to").flatMap(Int.init))
      END{ for(i=1;i<=top;i++) printf "%s\t%s\t%s\t%s\n", sid[i], sep[i], sac[i], stx[i] }
    ' "$LOG"
    ;;

  as-of-index)
    # Replay the first N log events (deterministic, disambiguates same-epoch bursts). PRD §12 R3.
    n="${1:-}"
    is_int "$n" || { echo "as-of-index: N must be a non-negative integer" >&2; exit 1; }
    [ -f "$LOG" ] || exit 0
    awk -F'\t' -v lim="$n" '
      function drop(x,   i,j){ for(i=1;i<=top;i++) if(sid[i]==x){ for(j=i;j<top;j++){sid[j]=sid[j+1];sep[j]=sep[j+1];sac[j]=sac[j+1];stx[j]=stx[j+1]} top--; return } }
      $1=="iso_ts"{next}
      { c++; if(c>lim) next; op=$3; id=$4; ep=$2; ac=$5; tx=$7 }
      c<=lim && (op=="push"||op=="push-many"||op=="restore"){ top++; sid[top]=id; sep[top]=ep; sac[top]=ac; stx[top]=tx; next }
      c<=lim && (op=="pop"||op=="pop-clip"){ if(top>0) top--; next }
      c<=lim && (op=="remove"||op=="evict"){ drop(id); next }
      c<=lim && op=="clear"{ if($7==""||$7=="-"){top=0} else {nc=split($7,cl," "); for(ci=1;ci<=nc;ci++) drop(cl[ci])} next }
      function moveid(id, pos,   j,i,n,Ai,Ae,Aa,At,d){ n=top; for(j=1;j<=top;j++) if(sid[j]==id) break; if(j>top) return; Ai=sid[j]; Ae=sep[j]; Aa=sac[j]; At=stx[j]; for(i=j;i<top;i++){sid[i]=sid[i+1];sep[i]=sep[i+1];sac[i]=sac[i+1];stx[i]=stx[i+1]} top--; if(pos<1)pos=1; if(pos>n)pos=n; d=n-pos+1; for(i=top;i>=d;i--){sid[i+1]=sid[i];sep[i+1]=sep[i];sac[i+1]=sac[i];stx[i+1]=stx[i]} sid[d]=Ai; sep[d]=Ae; sac[d]=Aa; stx[d]=At; top++ }
      c<=lim && op=="edit"{ for(i=1;i<=top;i++) if(sid[i]==id) stx[i]=tx; next }
      c<=lim && op=="move"{ mp=""; nq=split($6,qq,";"); for(qi=1;qi<=nq;qi++) if(qq[qi]~/^to=/){mp=substr(qq[qi],4);break} if(mp~/^[+-]?[0-9]+$/) moveid(id,mp+0); next }   # to=<int> only; malformed/absent ref = NO-OP (parity w/ Swift parseMoveTarget)
      END{ for(i=1;i<=top;i++) printf "%s\t%s\t%s\t%s\n", sid[i], sep[i], sac[i], stx[i] }
    ' "$LOG"
    ;;

  *)
    echo "usage: stack.sh push [--dest APP] [--win TITLE] [--ttl SECS] <t> | push-many <a> <b>.. | pop | pop-clip | peek | peek-clip | show | count | clear | remove <id> | move <id> <pos> | edit <id> <t> | defer <id> <secs> | restore <id> | history [N] | as-of <epoch> | dump-tsv | as-of-index <N> | capabilities" >&2
    exit 1
    ;;
esac
